#!/usr/bin/env sh
set -eu

chart_dir="${1:-./charts/zero-trust-mesh}"
script_dir="$(CDPATH="" cd "$(dirname "$0")" && pwd)"
values_file="$script_dir/service-owned-allow-values.yaml"
rendered="$(mktemp)"
trap 'rm -f "$rendered"' EXIT

helm template ztm-service-owned "$chart_dir" -n default -f "$values_file" > "$rendered"

require_pattern() {
  pattern="$1"
  message="$2"
  if ! grep -q "$pattern" "$rendered"; then
    echo "$message" >&2
    exit 1
  fi
}

reject_pattern() {
  pattern="$1"
  message="$2"
  if grep -q "$pattern" "$rendered"; then
    echo "$message" >&2
    exit 1
  fi
}

require_pattern 'name: ztm-service-owned-zero-trust-mesh-service-deny-all' "service deny-all baseline was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-nginx-curl2-test-80' "ingress NetworkPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-nginx-curl2' "ingress AuthorizationPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-ingress-nginx-80' "ingress-controller NetworkPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-ingress-nginx' "ingress-controller AuthorizationPolicy was not rendered"
require_pattern 'app.kubernetes.io/name: ingress-nginx' "ingress-controller source selector was not rendered"
require_pattern 'app.kubernetes.io/component: controller' "ingress-controller component selector was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-internal-alb-80' "internal ALB NetworkPolicy was not rendered"
require_pattern 'cidr: "172.31.0.0/16"' "internal ALB sourceIpBlocks was not rendered"
require_pattern 'name: ztm-service-owned-zero-trust-mesh-allow-dns-egress' "DNS egress NetworkPolicy was not rendered"
require_pattern 'name: ztm-service-owned-zero-trust-mesh-allow-istiod-egress' "istiod egress NetworkPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-egress-to-nginx-curl3-80' "egress NetworkPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-egress-to-external-hosts' "external host egress NetworkPolicy was not rendered"
require_pattern 'name: external-example-com' "external host ServiceEntry was not rendered"
reject_pattern 'operation:' "ingress without methods/paths rendered an empty Istio operation filter"
reject_pattern 'name: allow-nginx-curl-to-nginx-curl3-80$' "egress rendered legacy target-side ingress NetworkPolicy"
reject_pattern 'name: allow-nginx-curl-to-nginx-curl3$' "egress rendered legacy target-side AuthorizationPolicy"
