#!/usr/bin/env sh
set -eu

chart_dir="${1:-./charts/zero-trust-mesh}"
script_dir="$(CDPATH="" cd "$(dirname "$0")" && pwd)"
values_file="$script_dir/service-deny-all-values.yaml"
rendered="$(mktemp)"
trap 'rm -f "$rendered"' EXIT

helm template ztm-service-deny-all "$chart_dir" -n default -f "$values_file" > "$rendered"

require_pattern() {
  pattern="$1"
  message="$2"
  if ! grep -Eq "$pattern" "$rendered"; then
    echo "$message" >&2
    cat "$rendered" >&2
    exit 1
  fi
}

reject_pattern() {
  pattern="$1"
  message="$2"
  if grep -Eq "$pattern" "$rendered"; then
    echo "$message" >&2
    grep -En "$pattern" "$rendered" >&2 || true
    exit 1
  fi
}

require_pattern 'kind: NetworkPolicy' "service-level deny-all NetworkPolicy was not rendered"
require_pattern 'kind: AuthorizationPolicy' "service-level deny-all AuthorizationPolicy was not rendered"
require_pattern 'name: ztm-service-deny-all-zero-trust-mesh-service-deny-all' "service-level deny-all resource name was not rendered"
require_pattern 'app: frontend' "service-level deny-all selector did not include custom app label"
require_pattern 'component: api' "service-level deny-all selector did not include custom component label"
require_pattern 'policyTypes:[[:space:]]*$' "NetworkPolicy policyTypes was not rendered"
require_pattern '    - Ingress' "NetworkPolicy does not deny inbound traffic"
require_pattern '    - Egress' "NetworkPolicy does not deny outbound traffic"
reject_pattern 'default-deny-all' "service-level deny-all unexpectedly rendered namespace-wide default deny"

