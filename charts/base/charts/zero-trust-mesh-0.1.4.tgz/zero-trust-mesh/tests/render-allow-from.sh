#!/usr/bin/env sh
set -eu

chart_dir="${1:-./charts/zero-trust-mesh}"
script_dir="$(CDPATH="" cd "$(dirname "$0")" && pwd)"
values_file="$script_dir/allow-from-values.yaml"
rendered="$(mktemp)"
trap 'rm -f "$rendered"' EXIT

helm template ztm-allow-from "$chart_dir" -n default -f "$values_file" > "$rendered"

require_pattern() {
  pattern="$1"
  message="$2"
  if ! grep -q "$pattern" "$rendered"; then
    echo "$message" >&2
    exit 1
  fi
}

require_pattern 'name: allow-nginx-curl-ingress-from-nginx-curl2-test-80' "ingress NetworkPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-nginx-curl2' "ingress AuthorizationPolicy was not rendered"
require_pattern 'app: nginx-curl-test' "ingress target selector was not rendered"
require_pattern 'app: nginx-curl2-test' "ingress source selector was not rendered"
require_pattern 'cluster.local/ns/default/sa/nginx-curl2' "ingress source principal was not rendered"
require_pattern 'name: ztm-allow-from-zero-trust-mesh-service-deny-all' "service deny-all baseline was not rendered"
