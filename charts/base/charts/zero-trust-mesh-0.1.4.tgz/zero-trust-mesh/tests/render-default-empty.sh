#!/usr/bin/env sh
set -eu

chart_dir="${1:-./charts/zero-trust-mesh}"
rendered="$(mktemp)"
trap 'rm -f "$rendered"' EXIT

helm template ztm-default "$chart_dir" -n default > "$rendered"

if grep -Eq 'allow-ztm-default-to-backend|external-api-stripe-com|external-ip-|192\.0\.2\.10|api\.stripe\.com' "$rendered"; then
  echo "default render contains sample egress resources; default egress must be []" >&2
  grep -En 'allow-ztm-default-to-backend|external-api-stripe-com|external-ip-|192\.0\.2\.10|api\.stripe\.com' "$rendered" >&2 || true
  exit 1
fi
