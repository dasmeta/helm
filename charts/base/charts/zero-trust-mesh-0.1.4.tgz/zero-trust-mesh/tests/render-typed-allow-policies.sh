#!/usr/bin/env sh
set -eu

chart_dir="${1:-./charts/zero-trust-mesh}"
script_dir="$(CDPATH="" cd "$(dirname "$0")" && pwd)"
values_file="$script_dir/typed-allow-policies-values.yaml"
rendered="$(mktemp)"
trap 'rm -f "$rendered"' EXIT

helm template ztm-typed-allow "$chart_dir" -n default -f "$values_file" > "$rendered"

require_pattern() {
  pattern="$1"
  message="$2"
  if ! grep -q "$pattern" "$rendered"; then
    echo "$message" >&2
    exit 1
  fi
}

require_pattern 'name: allow-nginx-curl-ingress-from-nginx-curl2-test-80' "typed ingress NetworkPolicy was not rendered"
require_pattern 'name: allow-nginx-curl-ingress-from-nginx-curl2' "typed ingress AuthorizationPolicy was not rendered"
require_pattern 'app: nginx-curl2-test' "typed ingress source selector was not rendered from podLabels"
require_pattern 'name: allow-nginx-curl-egress-to-nginx-curl2-80' "typed service egress NetworkPolicy was not rendered"
require_pattern 'name: ztm-typed-allow-zero-trust-mesh-allow-dns-egress' "typed policy DNS egress NetworkPolicy was not rendered"
require_pattern 'k8s-app: kube-dns' "typed policy DNS egress selector was not rendered"
require_pattern 'name: allow-nginx-curl-egress-to-external-hosts' "typed host egress NetworkPolicy was not rendered"
require_pattern 'name: external-example-com' "typed host ServiceEntry was not rendered"
require_pattern 'name: external-ip-' "typed IP ServiceEntry was not rendered"
require_pattern 'cidr: "192.0.2.10/32"' "typed IP egress NetworkPolicy was not rendered"
